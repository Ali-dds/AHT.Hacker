def kk(t):
   import sys, time
   for txt in t + "\n":
        sys.stdout.write(txt)
        sys.stdout.flush()
        time.sleep(9. / 540)
a = "\033[1;35m ==A=L=T=O=R=K=Y==>>.[1.]\033[1;32m Install WPSeku "
b = "\033[1;35m ==A=L=T=O=R=K=Y==>>..[2.]\033[1;32m Install InjeCtor-SY "
c = "\033[1;35m ==A=L=T=O=R=K=Y==>>...[3.]\033[1;32m Install 0xSQLiNJ "
d = "\033[1;35m ==A=L=T=O=R=K=Y==>>....[4.]\033[1;32m Install sqlmap "
e = "\033[1;35m ==A=L=T=O=R=K=Y==>>.....[5.]\033[1;32m Install Xshell "
f = "\033[1;35m ==A=L=T=O=R=K=Y==>>......[6.]\033[1;32m Install XAttacker "
g = "\033[1;35m ==A=L=T=O=R=K=Y==>>.......[7.]\033[1;32m Install OWScan "
h = "\033[1;35m ==A=L=T=O=R=K=Y==>>........[8.]\033[1;32m Install Breacher "
i = "\033[1;35m ==A=L=T=O=R=K=Y==>>.........[9.]\033[1;32m Install Nmap "
j = "\033[1;35m ==A=L=T=O=R=K=Y==>>........[10.]\033[1;32m Install TXTool "
k = "\033[1;35m ==A=L=T=O=R=K=Y==>>.......[11.]\033[1;32m Install A-Rat "
l = "\033[1;35m ==A=L=T=O=R=K=Y==>>......[12.]\033[1;32m Install Facebook Brute "
m = "\033[1;35m ==A=L=T=O=R=K=Y==>>.....[13.]\033[1;32m Install InstaHack "
n = "\033[1;35m ==A=L=T=O=R=K=Y==>>....[14.]\033[1;32m Install gmail_attacker "
o = "\033[1;35m ==A=L=T=O=R=K=Y==>>...[15.]\033[1;32m Install Hash Buster "
p = "\033[1;35m ==A=L=T=O=R=K=Y==>>..[16.]\033[1;32m Install weeman "
q = "\033[1;35m ==A=L=T=O=R=K=Y==>>...[17.]\033[1;32m Install wifite "
r = "\033[1;35m ==A=L=T=O=R=K=Y==>>....[18.]\033[1;32m Install Sudo "
s = "\033[1;35m ==A=L=T=O=R=K=Y==>>.....[19.]\033[1;32m Install Ubuntu "
t = "\033[1;35m ==A=L=T=O=R=K=Y==>>......[20.]\033[1;32m Install Fedora "
u = "\033[1;35m ==A=L=T=O=R=K=Y==>>.......[21.]\033[1;32m Install Ninja-WordList "
v = "\033[1;35m ==A=L=T=O=R=K=Y==>>........[00.]\033[1;32m Install Exit "
w = "\033[1;35m ==A=L=T=O=R=K=Y==>>.........[99.]\033[1;32m Install Back To Home "
kk(a)
kk(b)
kk(c)
kk(d)
kk(e)
kk(f)
kk(g)
kk(h)
kk(i)
kk(j)
kk(k)
kk(l)
kk(m)
kk(n)
kk(o)
kk(p)
kk(q)
kk(r)
kk(s)
kk(t)
kk(u)
kk(v)
kk(w)
